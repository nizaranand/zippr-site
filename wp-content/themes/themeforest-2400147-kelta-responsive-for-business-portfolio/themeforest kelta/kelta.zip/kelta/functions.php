<?php

require_once('wpv_common/wpv_framework.php');

new Wpv_Framework(array(
	'name' => 'kelta',
	'slug' => 'kelta'
));


