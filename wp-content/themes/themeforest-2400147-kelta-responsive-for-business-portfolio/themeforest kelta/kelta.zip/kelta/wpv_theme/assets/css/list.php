<?php

return array(
	'base',
	'wpvslider',
	'slider_styles',
	'jplayer/blue_monday/style',
	'layout',
	'colorbox/colorbox',
	'wp',
	'ie',
	'../../../cache/configurable',
);
