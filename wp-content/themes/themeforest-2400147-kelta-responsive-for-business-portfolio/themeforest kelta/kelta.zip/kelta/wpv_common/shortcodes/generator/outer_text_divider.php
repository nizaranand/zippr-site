<?php
return array(
	"name" => __("Outer text divider", 'wpv') ,
	"value" => "outer_text_divider",
	"options" => array(
		array(
			"name" => __("Text", 'wpv') ,
			"id" => "text",
			"default" => '',
			"type" => "textarea",
		) ,
	) ,
);
