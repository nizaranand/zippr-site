<?php
return array(
	"name" => __('Table', 'wpv') ,
	"value" => 'table',
	"options" => array(
		array(
			'name' => __('Content', 'wpv') ,
			'desc' => __('Please insert a valid HTML table, you can use thead and tfood if you wish', 'wpv') ,
			'id' => 'content',
			'type' => 'textarea'
		) ,
	) ,
);
