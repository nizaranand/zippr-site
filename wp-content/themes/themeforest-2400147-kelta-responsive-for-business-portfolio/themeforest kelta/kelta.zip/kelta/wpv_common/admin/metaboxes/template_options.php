<?php
return array(
array(
	'name' => '',
	'type' => 'templates',
),
);