<?php
return array(
	'name' => __('Help', 'wpv'),
	'auto' => true,
	'config' => array(
		array(
			'no_save_button' => true,
			'name' => __('Help', 'wpv'),
			'type' => 'title',
			'desc' => '',
		),
//----
		array(
			'type' => 'docs',
		),
		
	)
);