<li id="image-<?php echo $image->ID;?>" class="imageItemWrap">
<div class="sortItem">
	<table width="100%" cellspacing="0" cellpadding="3">
		<tr>
			<td class="hndle"><div></div></td>
			<td width="70">
				<a title="<?php echo $image->post_title;?>" class="thickbox" href="<?php echo $image->guid;?>" style="display:block;">
					<?php echo wp_get_attachment_image($image->ID, array(60,60));?>
				</a>
			</td>
			<td width="160">
				<strong><a title="<?php echo $image->post_title;?>" class="thickbox" href="<?php echo $image->guid;?>"><?php echo $image->post_title;?></a></strong>
				<br />
				<?php echo $date;?>
				<br />
				<?php echo $size;?>
			</td>
			<td>
				<?php echo mb_substr($image->post_content, 0, 50, get_option('blog_charset'));?>
			</td>
			<td width="90" align="center">
				<div class="button-secondary edit-item" style="margin-bottom: 2px;">Edit</div>
				<div class="button-secondary delete-item">Delete</div>
			</td>

		</tr>
	</table>
</div>
</li>