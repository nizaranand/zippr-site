<?php
/*
 * info box
 */

if(!isset($class)) {
	$class = '';
}
?>

<div class="wpv-config-row config-info <?php echo $class ?>">
	<?php echo $text ?>
</div>