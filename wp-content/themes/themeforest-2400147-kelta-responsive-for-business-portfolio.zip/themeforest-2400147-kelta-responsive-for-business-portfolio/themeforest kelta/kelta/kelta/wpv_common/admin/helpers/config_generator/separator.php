<div class="config-separator">
	<?php echo $name ?>
	<div class="handlediv" title="<?php _e('Click to toggle', 'wpv')?>"></div>
</div>
