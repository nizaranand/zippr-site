<?php
return array(
	"name" => __("Text divider", 'wpv') ,
	"value" => "text_divider",
	"options" => array(
		array(
			"name" => __("Text", 'wpv') ,
			"id" => "text",
			"default" => '',
			"type" => "textarea",
		) ,
	) ,
);
