<?php
// this file returns an array with the order of the file which are used when generation the Advanced Options page

return array(
	'advanced/general',
	'advanced/layouts',
	'advanced/style',
	'advanced/sliders',
	'advanced/config_management',
	'advanced/sidebars',
	'advanced/import',
);
