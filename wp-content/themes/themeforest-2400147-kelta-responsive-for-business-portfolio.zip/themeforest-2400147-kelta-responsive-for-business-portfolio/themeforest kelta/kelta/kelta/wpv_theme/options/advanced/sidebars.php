<?php

return array(

array(
	'name' => __('Manage sidebars', 'wpv'),
	'type' => 'start',
),
array(
	'id' => 'custom-sidebars',
	'type' => 'sidebar_management',
	'static' => true,
),
	array(
		'type' => 'end'
	),

);
