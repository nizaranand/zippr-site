<?php
// this file returns an array with the order of the file which are used when generation the Theme Options page

return array(
	'quick_setup/general',
);
