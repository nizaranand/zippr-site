Thank you for purchasing the Kelta theme from http://themeforest.net/ !

20 + videos are available here : http://zenden.vamtam.com/video-tutorials

Feel free to browse our solution database for videos and extra help - http://support.vamtam.com/solution/categories. Please note that you have to sigh up  to access the Help Desk.

Should you have any queries or want to share your feedback and remarks, don't hesitate to submit a ticket to our help desk: http://support.vamtam.com/helpdesk/tickets

Regards,
Vamtam team